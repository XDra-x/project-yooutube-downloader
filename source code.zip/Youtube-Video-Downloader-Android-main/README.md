# Youtube-Video-Downloader-Android
This repository contains code of YouTube Video Downloader in Android using Java. This Project uses android youtube extractor library, you can find it here: https://github.com/HaarigerHarald/android-youtubeExtractor
YouTube Video: https://youtu.be/tUesv5u5bvA
